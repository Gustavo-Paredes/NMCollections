import NFCManualScreen from './screens/NFCManualScreen';
