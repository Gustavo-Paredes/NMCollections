import calendar
from collections import OrderedDict
from datetime import timedelta

from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, Sum
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from apps.pedidos.models import Pedido


def get_ventas_metrics():
    """Calcula métricas generales de ventas."""
    total_ventas = Pedido.objects.aggregate(total=Sum('total'))['total'] or 0
    total_pedidos = Pedido.objects.count()
    pedidos_confirmados = Pedido.objects.filter(estado='confirmado').count()
    return {
        'total_ventas': total_ventas,
        'total_pedidos': total_pedidos,
        'pedidos_confirmados': pedidos_confirmados,
    }


def get_ventas_por_mes():
    """Calcula ventas por mes para los últimos 12 meses."""
    now = timezone.now()
    # Generar últimos 12 meses
    meses = [
        (now.replace(day=1) - timedelta(days=30 * i)).strftime('%Y-%m')
        for i in range(11, -1, -1)
    ]
    ventas_por_mes = OrderedDict((m, 0) for m in meses)

    # Filtrar pedidos del último año (aprox 365 días para evitar error de año bisiesto con replace)
    fecha_inicio = now - timedelta(days=365)
    pedidos = Pedido.objects.filter(fecha_pedido__gte=fecha_inicio).order_by('fecha_pedido')

    for p in pedidos:
        mes = p.fecha_pedido.strftime('%Y-%m')
        if mes in ventas_por_mes:
            ventas_por_mes[mes] += float(p.total or 0)

    labels = [
        f"{calendar.month_abbr[int(m.split('-')[1])]} {m.split('-')[0]}"
        for m in ventas_por_mes.keys()
    ]
    values = list(ventas_por_mes.values())
    return labels, values


def get_pedidos_por_estado():
    """Calcula la cantidad de pedidos por estado."""
    estados_choices = dict(Pedido._meta.get_field('estado').choices)
    pedidos_estado = Pedido.objects.values('estado').annotate(c=Count('id'))
    
    data = {
        estados_choices.get(e['estado'], e['estado']): e['c']
        for e in pedidos_estado
    }
    return list(data.keys()), list(data.values())


def get_ventas_por_metodo_pago():
    """Calcula las ventas totales por método de pago."""
    # Optimización: Usar agregación en DB en lugar de iterar en Python
    ventas = Pedido.objects.values('metodo_pago').annotate(total=Sum('total')).order_by('-total')
    
    data = {
        v['metodo_pago']: float(v['total'] or 0)
        for v in ventas if v['metodo_pago']
    }
    return list(data.keys()), list(data.values())


@swagger_auto_schema(
    method='get',
    operation_description="Reportes admin: métricas, ventas por mes, pedidos por estado y ventas por método de pago.",
    responses={200: openapi.Response('Reporte', examples={
        'application/json': {
            'metrics': {'total_ventas': 10000, 'total_pedidos': 20, 'pedidos_confirmados': 15},
            'ventas_por_mes': [1000, 2000, 3000],
            'labels_ventas_mes': ['Nov 2024', 'Dec 2024', 'Jan 2025'],
            'pedidos_estado_labels': ['pendiente', 'confirmado'],
            'pedidos_estado_values': [5, 15],
            'ventas_metodo_labels': ['WebPay', 'Transferencia'],
            'ventas_metodo_values': [7000, 3000],
        }
    })}
)
@api_view(['GET'])
@permission_classes([AllowAny])
def reportes_admin_api(request):
    """API para obtener datos de reportes administrativos."""
    metrics = get_ventas_metrics()
    labels_mes, values_mes = get_ventas_por_mes()
    labels_estado, values_estado = get_pedidos_por_estado()
    labels_metodo, values_metodo = get_ventas_por_metodo_pago()

    return Response({
        'metrics': metrics,
        'ventas_por_mes': values_mes,
        'labels_ventas_mes': labels_mes,
        'pedidos_estado_labels': labels_estado,
        'pedidos_estado_values': values_estado,
        'ventas_metodo_labels': labels_metodo,
        'ventas_metodo_values': values_metodo,
    })


@staff_member_required
def reportes_admin(request):
    """Vista para renderizar el panel de reportes administrativos."""
    metrics = get_ventas_metrics()
    labels_mes, values_mes = get_ventas_por_mes()
    labels_estado, values_estado = get_pedidos_por_estado()
    labels_metodo, values_metodo = get_ventas_por_metodo_pago()

    context = {
        'metrics': metrics,
        'url_csv': reverse('pedidos:informe_ventas'),
        'url_excel': reverse('pedidos:informe_ventas_excel'),
        'url_pdf': reverse('pedidos:informe_ventas_pdf'),
        'ventas_por_mes': values_mes,
        'labels_ventas_mes': labels_mes,
        'pedidos_estado_labels': labels_estado,
        'pedidos_estado_values': values_estado,
        'ventas_metodo_labels': labels_metodo,
        'ventas_metodo_values': values_metodo,
    }
    return render(request, 'admin/reportes_admin.html', context)
