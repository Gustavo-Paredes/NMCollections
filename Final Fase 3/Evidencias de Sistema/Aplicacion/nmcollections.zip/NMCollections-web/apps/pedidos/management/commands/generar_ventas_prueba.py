import random
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.pedidos.models import Pedido, PedidoProducto, EstadoPedidoChoices
from apps.productos.models import Producto


class Command(BaseCommand):
    help = 'Genera ventas de prueba compatibles con Webpay y reportes'

    def add_arguments(self, parser):
        parser.add_argument(
            '--cantidad',
            type=int,
            default=20,
            help='Cantidad de pedidos a generar'
        )

    def handle(self, *args, **options):
        cantidad = options['cantidad']
        User = get_user_model()
        from apps.usuarios.models import Rol
        
        # Obtener o crear rol de cliente
        rol_cliente, _ = Rol.objects.get_or_create(
            nombre='cliente',
            defaults={'descripcion': 'Rol para clientes registrados'}
        )
        
        # Obtener o crear usuario de prueba
        usuario, created = User.objects.get_or_create(
            email='cliente_prueba@example.com',
            defaults={
                'first_name': 'Cliente',
                'last_name': 'Prueba',
                'is_active': True,
                'rol': rol_cliente
            }
        )
        if created:
            usuario.set_password('testpass123')
            usuario.save()
            self.stdout.write(self.style.SUCCESS(f'Usuario creado: {usuario.email}'))

        # Verificar productos
        productos = list(Producto.objects.filter(estado='activo'))
        if not productos:
            self.stdout.write(self.style.ERROR('No hay productos activos. Crea productos primero.'))
            return

        self.stdout.write(f'Generando {cantidad} pedidos de prueba...')

        metodos_pago = ['Webpay', 'Transferencia', 'Efectivo']
        estados = [choice[0] for choice in EstadoPedidoChoices.choices]

        for i in range(cantidad):
            # Fecha aleatoria en el último año
            dias_atras = random.randint(0, 365)
            fecha_pedido = timezone.now() - timedelta(days=dias_atras)
            
            # Datos aleatorios
            estado = random.choice(estados)
            metodo_pago = random.choice(metodos_pago)
            
            # Crear pedido
            pedido = Pedido.objects.create(
                usuario=usuario,
                fecha_pedido=fecha_pedido,
                estado=estado,
                metodo_pago=metodo_pago,
                direccion_envio=f"Calle Falsa {random.randint(100, 999)}, Santiago",
                notas="Pedido generado automáticamente",
                # Campos adicionales para simular flujo real
                fecha_confirmacion=fecha_pedido + timedelta(minutes=5) if estado in ['confirmado', 'enviado', 'entregado'] else None,
            )

            # Agregar productos al pedido
            num_productos = random.randint(1, 5)
            productos_seleccionados = random.sample(productos, min(len(productos), num_productos))
            
            total_pedido = Decimal('0.00')

            for producto in productos_seleccionados:
                cantidad_prod = random.randint(1, 3)
                precio_total_linea = producto.precio_base * cantidad_prod
                
                PedidoProducto.objects.create(
                    pedido=pedido,
                    producto=producto,
                    cantidad=cantidad_prod,
                    precio_total=precio_total_linea
                )
                total_pedido += Decimal(precio_total_linea)

            # Actualizar total del pedido
            pedido.total = total_pedido
            pedido.save()

            # Forzar la fecha de creación (auto_now_add a veces sobreescribe)
            Pedido.objects.filter(id=pedido.id).update(fecha_pedido=fecha_pedido)

        self.stdout.write(self.style.SUCCESS(f'Se generaron {cantidad} pedidos exitosamente.'))
