from django.apps import AppConfig


class ApiMovilConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.api_movil'
    verbose_name = 'API Móvil'