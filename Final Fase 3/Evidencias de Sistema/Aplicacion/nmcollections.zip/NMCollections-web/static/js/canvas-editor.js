/**
 * Canvas Editor - Editor de Trading Cards
 * Gestiona la creación y edición de cartas personalizadas
 */

// ============================================================================
// VARIABLES GLOBALES
// ============================================================================
let canvas;
let canvasReverso;
let plantillaSeleccionada = null;
let caraActual = 'frente'; // 'frente' o 'reverso'
let imagenPersonalizadaActual = null; // Imagen cargada por el usuario
let cartaActualId = null; // ID de la carta si se está editando

// ============================================================================
// INICIALIZACIÓN
// ============================================================================

function verificarLibrerias() {
    console.log('🔍 Verificando librerías...');
    const fabricOk = typeof fabric !== 'undefined';
    const axiosOk = typeof axios !== 'undefined';
    return fabricOk && axiosOk;
}

function inicializarCanvas() {
    const canvasElement = document.getElementById('cardCanvas');
    if (!canvasElement) return;

    // Canvas frontal
    canvas = new fabric.Canvas('cardCanvas', {
        backgroundColor: '#ffffff',
        width: 320,
        height: 420,
        selection: true,
        renderOnAddRemove: true,
        enableRetinaScaling: true,
        preserveObjectStacking: true
    });

    // Canvas reverso
    canvasReverso = new fabric.Canvas('cardCanvasReverso', {
        backgroundColor: '#ffffff',
        width: 320,
        height: 420,
        selection: true,
        renderOnAddRemove: true,
        enableRetinaScaling: true,
        preserveObjectStacking: true
    });

    // Event listeners para selección
    [canvas, canvasReverso].forEach(c => {
        c.on('selection:created', handleSelection);
        c.on('selection:updated', handleSelection);
        c.on('selection:cleared', handleDeselection);
    });

    // Listeners para propiedades de texto
    setupPropertyListeners();
}

function handleSelection(e) {
    const obj = e.selected[0];
    const propertiesPanel = document.getElementById('propertiesPanel');
    const emptyMsg = document.getElementById('empty-properties');
    const textProps = document.getElementById('text-properties');
    const imageProps = document.getElementById('image-properties');

    propertiesPanel.classList.remove('hidden');
    emptyMsg.style.display = 'none';
    textProps.style.display = 'none';
    imageProps.style.display = 'none';

    if (obj.customType === 'texto-personalizado' || obj.type === 'textbox') {
        textProps.style.display = 'block';
        updateTextPropertiesUI(obj);
    } else if (obj.type === 'image' || obj.customId === 'imagen_personalizada') {
        imageProps.style.display = 'block';
        updateImagePropertiesUI(obj);
    } else {
        emptyMsg.style.display = 'block';
    }
}

function handleDeselection() {
    const propertiesPanel = document.getElementById('propertiesPanel');
    // Opcional: Ocultar panel o mostrar mensaje vacío
    document.getElementById('empty-properties').style.display = 'block';
    document.getElementById('text-properties').style.display = 'none';
    document.getElementById('image-properties').style.display = 'none';
}

function setupPropertyListeners() {
    // Texto
    document.getElementById('prop-text-content').addEventListener('input', (e) => updateActiveObject('text', e.target.value));
    document.getElementById('prop-font-family').addEventListener('change', (e) => updateActiveObject('fontFamily', e.target.value));
    document.getElementById('prop-font-size').addEventListener('input', (e) => {
        document.getElementById('prop-font-size-val').value = e.target.value;
        updateActiveObject('fontSize', parseInt(e.target.value));
    });
    document.getElementById('prop-text-color').addEventListener('input', (e) => updateActiveObject('fill', e.target.value));

    document.getElementById('prop-bold').addEventListener('click', () => toggleTextStyle('fontWeight', 'bold'));
    document.getElementById('prop-italic').addEventListener('click', () => toggleTextStyle('fontStyle', 'italic'));
    document.getElementById('prop-underline').addEventListener('click', () => toggleTextStyle('underline'));

    // Imagen
    document.getElementById('prop-opacity').addEventListener('input', (e) => updateActiveObject('opacity', parseFloat(e.target.value)));
}

function updateActiveObject(prop, value) {
    const c = caraActual === 'frente' ? canvas : canvasReverso;
    const obj = c.getActiveObject();
    if (obj) {
        obj.set(prop, value);
        c.requestRenderAll();
    }
}

function toggleTextStyle(prop, value = true) {
    const c = caraActual === 'frente' ? canvas : canvasReverso;
    const obj = c.getActiveObject();
    if (obj) {
        if (prop === 'fontWeight') {
            obj.set(prop, obj.fontWeight === 'bold' ? 'normal' : 'bold');
        } else if (prop === 'fontStyle') {
            obj.set(prop, obj.fontStyle === 'italic' ? 'normal' : 'italic');
        } else if (prop === 'underline') {
            obj.set(prop, !obj.underline);
        }
        c.requestRenderAll();
        updateTextPropertiesUI(obj); // Refrescar botones
    }
}

function updateTextPropertiesUI(obj) {
    document.getElementById('prop-text-content').value = obj.text;
    document.getElementById('prop-font-family').value = obj.fontFamily;
    document.getElementById('prop-font-size').value = obj.fontSize;
    document.getElementById('prop-font-size-val').value = obj.fontSize;
    document.getElementById('prop-text-color').value = obj.fill;

    // Update button states
    document.getElementById('prop-bold').classList.toggle('active', obj.fontWeight === 'bold');
    document.getElementById('prop-italic').classList.toggle('active', obj.fontStyle === 'italic');
    document.getElementById('prop-underline').classList.toggle('active', obj.underline);
}

function updateImagePropertiesUI(obj) {
    document.getElementById('prop-opacity').value = obj.opacity || 1;
}

function configurarCSRF() {
    const csrftoken = getCookie('csrftoken');
    axios.defaults.headers.common['X-CSRFToken'] = csrftoken;
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

document.addEventListener('DOMContentLoaded', function () {
    if (!verificarLibrerias()) return;

    configurarCSRF();
    inicializarCanvas();
    cargarPlantillas();

    // Listener for global confirm modal events
    document.addEventListener('confirmed', function (e) {
        if (e.target.id === 'btn-finalizar') {
            finalizarCarta();
        } else if (e.target.id === 'btn-limpiar') {
            limpiarCanvas();
        }
    });

    // Verificar si hay una carta a cargar
    const urlParams = new URLSearchParams(window.location.search);
    const cartaId = urlParams.get('carta_id');

    if (cartaId) {
        cartaActualId = cartaId;
        cargarCartaExistente(cartaId);
    }
});

// ============================================================================
// GESTIÓN DE UI
// ============================================================================

function switchPanel(panelId) {
    // Update Sidebar Icons
    document.querySelectorAll('.icon-btn').forEach(btn => btn.classList.remove('active'));
    event.currentTarget.classList.add('active');

    // Update Drawer Panels
    document.querySelectorAll('.drawer-panel').forEach(panel => panel.classList.remove('active'));
    document.getElementById(`panel-${panelId}`).classList.add('active');
}

function mostrarLoading(show = true, mensaje = 'Cargando...') {
    const overlay = document.getElementById('loadingOverlay');
    overlay.style.display = show ? 'flex' : 'none';
}

function mostrarNotificacion(mensaje, tipo = 'info') {
    const container = document.getElementById('nm-toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = `alert alert-${tipo === 'error' ? 'danger' : tipo} shadow-sm mb-2`;
    toast.innerHTML = `<i class="fas fa-info-circle me-2"></i>${mensaje}`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function createToastContainer() {
    const div = document.createElement('div');
    div.id = 'nm-toast-container';
    div.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; width: 300px;';
    document.body.appendChild(div);
    return div;
}

// ============================================================================
// GESTIÓN DE PLANTILLAS
// ============================================================================

async function cargarPlantillas() {
    try {
        mostrarLoading(true);
        const response = await axios.get('/personalizacion/canvas-editor/plantillas_disponibles/');
        const plantillas = response.data;

        const container = document.getElementById('plantillasContainer');
        container.innerHTML = '';

        if (!plantillas.length) {
            container.innerHTML = '<p class="text-white text-center">No hay plantillas disponibles</p>';
            return;
        }

        plantillas.forEach(plantilla => {
            const div = document.createElement('div');
            div.className = 'plantilla-card';
            div.style.cssText = 'background: #2c2c2c; padding: 10px; margin-bottom: 10px; border-radius: 8px; cursor: pointer; border: 1px solid #444;';
            div.innerHTML = `
                <h6 class="text-white mb-1">${plantilla.nombre}</h6>
                <small class="text-white">${plantilla.tipo_carta}</small>
            `;
            div.onclick = () => seleccionarPlantilla(plantilla);
            container.appendChild(div);
        });

    } catch (error) {
        console.error('Error cargando plantillas:', error);
        mostrarNotificacion('Error cargando plantillas', 'error');
    } finally {
        mostrarLoading(false);
    }
}

function seleccionarPlantilla(plantilla) {
    plantillaSeleccionada = plantilla;

    // Highlight selected
    document.querySelectorAll('.plantilla-card').forEach(c => c.style.borderColor = '#444');
    event.currentTarget.style.borderColor = 'var(--verde-principal)';

    canvas.clear();
    if (plantilla.imagen_marco_url) {
        cargarMarcoConFabric(plantilla.imagen_marco_url);
    }

    document.getElementById('btn-finalizar').disabled = false;
    document.getElementById('btn-guardar').disabled = false;
}

function cargarMarcoConFabric(url) {
    const c = caraActual === 'frente' ? canvas : canvasReverso;
    fabric.Image.fromURL(url, function (img) {
        // Lógica de escalado simple para llenar
        const scale = Math.max(c.width / img.width, c.height / img.height);
        img.set({
            scaleX: scale,
            scaleY: scale,
            left: c.width / 2,
            top: c.height / 2,
            originX: 'center',
            originY: 'center',
            selectable: false,
            evented: false
        });
        c.add(img);
        img.sendToBack();
    }, { crossOrigin: 'anonymous' });
}

// ============================================================================
// TEXTO
// ============================================================================

function agregarTextoPredefinido(tipo) {
    let config = {
        text: 'Texto',
        fontSize: 20,
        fontWeight: 'normal'
    };

    switch (tipo) {
        case 'titulo':
            config = { text: 'TÍTULO', fontSize: 32, fontWeight: 'bold' };
            break;
        case 'subtitulo':
            config = { text: 'Subtítulo', fontSize: 24, fontWeight: 'bold' };
            break;
        case 'cuerpo':
            config = { text: 'Lorem ipsum dolor sit amet', fontSize: 14, fontWeight: 'normal' };
            break;
    }

    const c = caraActual === 'frente' ? canvas : canvasReverso;
    const textObj = new fabric.Textbox(config.text, {
        left: c.width / 2,
        top: c.height / 2,
        width: 200,
        fontSize: config.fontSize,
        fontWeight: config.fontWeight,
        fontFamily: 'Arial',
        fill: '#000000',
        originX: 'center',
        originY: 'center',
        textAlign: 'center',
        customType: 'texto-personalizado'
    });

    c.add(textObj);
    c.setActiveObject(textObj);
    c.renderAll();
}

// ============================================================================
// IMÁGENES
// ============================================================================

function subirImagenPersonalizada(archivo) {
    if (!archivo || !archivo.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        imagenPersonalizadaActual = { data: e.target.result, archivo };
        document.getElementById('imgPreview').src = e.target.result;
        document.getElementById('previewImagenPersonalizada').style.display = 'block';
    };
    reader.readAsDataURL(archivo);
}

function aplicarImagenAlCanvas() {
    if (!imagenPersonalizadaActual) return;

    const c = caraActual === 'frente' ? canvas : canvasReverso;
    fabric.Image.fromURL(imagenPersonalizadaActual.data, (img) => {
        const scale = Math.min(c.width / img.width, c.height / img.height) * 0.8;
        img.set({
            left: c.width / 2,
            top: c.height / 2,
            originX: 'center',
            originY: 'center',
            scaleX: scale,
            scaleY: scale,
            customId: 'imagen_personalizada'
        });
        c.add(img);
        c.setActiveObject(img);
        c.renderAll();
    });
}

function eliminarObjetoSeleccionado() {
    const c = caraActual === 'frente' ? canvas : canvasReverso;
    const obj = c.getActiveObject();
    if (obj) {
        c.remove(obj);
        c.renderAll();
        handleDeselection();
    }
}

function limpiarImagenPersonalizada() {
    imagenPersonalizadaActual = null;
    document.getElementById('previewImagenPersonalizada').style.display = 'none';
    document.getElementById('imagenPersonalizada').value = '';
}

async function aplicarRecorteInteligente() {
    if (!imagenPersonalizadaActual) return;

    try {
        mostrarLoading(true, 'Recortando persona...');

        const formData = new FormData();
        formData.append('imagen', imagenPersonalizadaActual.archivo);
        formData.append('tipo_elemento', 'foto_jugador');
        formData.append('ancho', 300);
        formData.append('alto', 400);

        const response = await axios.post(
            '/personalizacion/canvas-editor/recorte_inteligente/',
            formData,
            { headers: { 'Content-Type': 'multipart/form-data' } }
        );

        if (response.data.url_imagen_procesada) {
            imagenPersonalizadaActual.data = response.data.url_imagen_procesada;
            document.getElementById('imgPreview').src = response.data.url_imagen_procesada;
            mostrarNotificacion('¡Recorte mágico aplicado!', 'success');
        }
    } catch (error) {
        console.error('Error en recorte:', error);
        if (error.response && error.response.data && error.response.data.error) {
            mostrarNotificacion(error.response.data.error, 'error');
        } else {
            mostrarNotificacion('No se pudo recortar la imagen. Inténtalo de nuevo.', 'error');
        }
    } finally {
        mostrarLoading(false);
    }
}

// ============================================================================
// UTILIDADES
// ============================================================================

function cambiarCara(cara) {
    caraActual = cara;
    document.getElementById('btn-frente').classList.toggle('active', cara === 'frente');
    document.getElementById('btn-reverso').classList.toggle('active', cara === 'reverso');

    document.getElementById('canvas-frente').style.display = cara === 'frente' ? 'flex' : 'none';
    document.getElementById('canvas-reverso').style.display = cara === 'reverso' ? 'flex' : 'none';
}

function limpiarCanvas() {
    canvas.clear();
    canvasReverso.clear();
    if (plantillaSeleccionada) seleccionarPlantilla(plantillaSeleccionada); // Recargar marco
}

// ============================================================================
// GUARDAR / FINALIZAR
// ============================================================================

function obtenerParametrosCanvas() {
    const parametros = [];

    // Recorrer objetos del canvas para guardar su estado
    // Nota: Esto es simplificado, idealmente guardaríamos JSON completo de fabric
    const objetos = canvas.getObjects();
    objetos.forEach(obj => {
        if (obj.customType === 'texto-personalizado') {
            parametros.push({
                nombre_parametro: 'texto_' + Math.random().toString(36).substr(2, 9),
                tipo_parametro: 'texto',
                valor: JSON.stringify({
                    text: obj.text,
                    left: obj.left,
                    top: obj.top,
                    fontSize: obj.fontSize,
                    fontFamily: obj.fontFamily,
                    fill: obj.fill,
                    fontWeight: obj.fontWeight,
                    fontStyle: obj.fontStyle,
                    underline: obj.underline
                })
            });
        }
    });

    return parametros;
}

async function guardarCarta(redirect = true) {
    const nombreInput = document.getElementById('nombreCarta');
    const nombreCarta = nombreInput.value.trim();

    if (!nombreCarta) {
        mostrarNotificacion('Debes ponerle un nombre a tu carta', 'error');
        nombreInput.focus();
        nombreInput.style.borderBottom = '2px solid red';
        return false;
    } else {
        nombreInput.style.borderBottom = '2px solid var(--verde-principal)';
    }

    if (!plantillaSeleccionada) {
        mostrarNotificacion('Selecciona una plantilla primero', 'warning');
        return false;
    }

    try {
        mostrarLoading(true, 'Guardando carta...');

        const parametros = obtenerParametrosCanvas();

        // 1. Guardar metadatos de la carta
        const response = await axios.post('/personalizacion/canvas-editor/guardar_carta_temporal/', {
            plantilla_id: plantillaSeleccionada.id,
            nombre_carta: nombreCarta,
            parametros: parametros,
            carta_id: cartaActualId // Enviar ID si estamos editando
        });

        if (response.data.status === 'success') {
            cartaActualId = response.data.carta_id;

            // 2. Generar y subir imagen
            const dataURL = canvas.toDataURL({
                format: 'png',
                quality: 1,
                multiplier: 1
            });

            const formData = new FormData();
            formData.append('imagen_data', dataURL);

            await axios.post(`/personalizacion/guardar-imagen/${cartaActualId}/`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            mostrarNotificacion('Carta guardada exitosamente', 'success');

            if (redirect) {
                setTimeout(() => {
                    window.location.href = '/personalizacion/mis-cartas/';
                }, 1500);
            } else {
                // Actualizar URL sin recargar si es nueva carta
                if (!window.location.search.includes('carta_id')) {
                    const newUrl = window.location.pathname + '?carta_id=' + cartaActualId;
                    window.history.pushState({ path: newUrl }, '', newUrl);
                }
            }

            return true;
        }

    } catch (error) {
        console.error('Error guardando carta:', error);
        mostrarNotificacion('Error al guardar la carta', 'error');
        return false;
    } finally {
        mostrarLoading(false);
    }
}

async function finalizarCarta() {
    if (!plantillaSeleccionada && !cartaActualId) return;

    // Confirmación ya manejada por el modal global
    try {
        // Primero guardar cambios pendientes (sin redirigir)
        const guardadoExitoso = await guardarCarta(false);
        if (!guardadoExitoso) return;

        mostrarLoading(true, 'Finalizando...');

        const response = await axios.post(`/personalizacion/finalizar-carta/${cartaActualId}/`);

        if (response.data.success) {
            mostrarNotificacion('Carta finalizada correctamente', 'success');
            setTimeout(() => {
                window.location.href = '/personalizacion/mis-cartas/';
            }, 1500);
        }

    } catch (error) {
        console.error('Error finalizando:', error);
        mostrarNotificacion('Error al finalizar la carta', 'error');
    } finally {
        mostrarLoading(false);
    }
}

async function cargarCartaExistente(id) {
    try {
        mostrarLoading(true, 'Cargando carta...');
        const response = await axios.get(`/personalizacion/cartas/${id}/preview/`);
        const carta = response.data;

        // 1. Cargar nombre
        document.getElementById('nombreCarta').value = carta.nombre;

        // 2. Seleccionar plantilla (esto limpia el canvas)
        // Necesitamos encontrar la plantilla completa en la lista cargada o usar la data de la carta
        // Por simplicidad, usamos la data de la carta para cargar el marco
        plantillaSeleccionada = carta.plantilla;

        // Cargar marco
        if (carta.plantilla.imagen_marco_url) {
            cargarMarcoConFabric(carta.plantilla.imagen_marco_url);
        }

        // 3. Restaurar parámetros (textos, etc)
        // Esperar un poco a que cargue el marco
        setTimeout(() => {
            if (carta.parametros && carta.parametros.length > 0) {
                carta.parametros.forEach(param => {
                    if (param.tipo_parametro === 'texto') {
                        try {
                            const props = JSON.parse(param.valor);
                            const textObj = new fabric.Textbox(props.text, {
                                ...props,
                                customType: 'texto-personalizado'
                            });
                            canvas.add(textObj);
                        } catch (e) {
                            console.error('Error parseando parametro:', e);
                        }
                    }
                });
                canvas.renderAll();
            }
        }, 500);

        document.getElementById('btn-finalizar').disabled = false;
        document.getElementById('btn-guardar').disabled = false;

    } catch (error) {
        console.error('Error cargando carta:', error);
        mostrarNotificacion('Error al cargar la carta', 'error');
    } finally {
        mostrarLoading(false);
    }
}
