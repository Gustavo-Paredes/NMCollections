/**
 * admin_subastas.js
 * Manejo de notificaciones (toasts) y contadores de tiempo para subastas.
 */

// --- Notificaciones (Toasts) ---

function mostrarNotificacion(mensaje, tipo = 'error') {
    const tipos = {
        success: { icon: 'check-circle', clase: 'success' },
        error: { icon: 'times-circle', clase: 'danger' },
        warning: { icon: 'exclamation-triangle', clase: 'warning' },
        info: { icon: 'info-circle', clase: 'info' }
    };
    const t = tipos[tipo] || tipos.info;

    let contenedor = document.getElementById('nm-toast-container');
    if (!contenedor) {
        contenedor = document.createElement('div');
        contenedor.id = 'nm-toast-container';
        // Las clases CSS se encargarán del estilo, pero mantenemos la estructura básica
        document.body.appendChild(contenedor);
    }

    const toast = document.createElement('div');
    toast.className = `nm-toast alert alert-${t.clase}`;

    toast.innerHTML = `
        <div class="d-flex align-items-start">
            <i class="fas fa-${t.icon} me-2 mt-1"></i>
            <div class="flex-grow-1">${mensaje}</div>
            <button type="button" class="btn-close ms-2" aria-label="Cerrar"></button>
        </div>
    `;

    // Evento para cerrar
    const btnClose = toast.querySelector('.btn-close');
    if (btnClose) {
        btnClose.onclick = () => {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300); // Esperar animación
        };
    }

    contenedor.appendChild(toast);

    // Auto eliminar después de 7 segundos
    setTimeout(() => {
        if (toast.parentElement) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 7000);
}

// --- Contadores de Tiempo ---

(function () {
    function pad(n) { return n < 10 ? '0' + n : n; }

    function formatRemaining(ms) {
        if (ms <= 0) return 'Finalizada';
        var total = Math.floor(ms / 1000);
        var days = Math.floor(total / 86400);
        var hours = Math.floor((total % 86400) / 3600);
        var mins = Math.floor((total % 3600) / 60);
        var secs = total % 60;
        var parts = [];
        if (days > 0) parts.push(days + 'd');
        parts.push(pad(hours) + 'h');
        parts.push(pad(mins) + 'm');
        parts.push(pad(secs) + 's');
        return parts.join(' ');
    }

    function updateTimers() {
        var nodes = document.querySelectorAll('.subasta-contador');
        if (!nodes.length) return;
        var now = new Date();
        nodes.forEach(function (node) {
            var fechaFin = node.getAttribute('data-fecha-fin');
            if (!fechaFin) return;
            // parse as local datetime
            var end = new Date(fechaFin);
            var diff = end - now;
            if (diff <= 0) {
                node.textContent = 'Finalizada';
                node.classList.add('finalizada');
            } else {
                node.textContent = formatRemaining(diff); // Eliminamos "Termina en: " para que sea más limpio, o lo dejamos si se prefiere
                node.classList.remove('finalizada');
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        updateTimers();
        setInterval(updateTimers, 1000);

        // Procesar notificaciones desde elementos del DOM (más robusto para templates)
        const toastData = document.getElementById('toast-data');
        if (toastData) {
            Array.from(toastData.children).forEach(el => {
                const msg = el.getAttribute('data-msg');
                const type = el.getAttribute('data-type');
                if (msg) mostrarNotificacion(msg, type);
            });
        }
    });
})();
