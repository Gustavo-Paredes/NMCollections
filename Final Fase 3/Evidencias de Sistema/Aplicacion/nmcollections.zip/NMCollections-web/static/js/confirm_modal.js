/**
 * confirm_modal.js
 * Manejo global de confirmaciones con modal Bootstrap.
 * 
 * Uso:
 * Agrega la clase 'btn-confirm-action' a cualquier botón o enlace.
 * Opcional: data-confirm-message="Tu mensaje aquí"
 * Opcional: data-confirm-title="Título del modal"
 * Opcional: data-confirm-btn-text="Texto botón confirmar"
 * Opcional: data-confirm-btn-class="Clase botón confirmar (ej: btn-danger)"
 */

document.addEventListener('DOMContentLoaded', function () {
    // Crear el modal dinámicamente si no existe en el HTML base (opcional, pero mejor tenerlo en base.html)
    // Asumimos que el modal ya está en base.html con id 'globalConfirmModal'

    const modalEl = document.getElementById('globalConfirmModal');
    let confirmModal = null;

    if (modalEl && typeof bootstrap !== 'undefined') {
        confirmModal = new bootstrap.Modal(modalEl);
    }

    let targetElement = null; // Elemento que disparó la acción (form o link)

    document.addEventListener('click', function (e) {
        const trigger = e.target.closest('.btn-confirm-action');
        if (trigger) {
            e.preventDefault();

            // Configurar textos
            const message = trigger.getAttribute('data-confirm-message') || '¿Estás seguro de realizar esta acción?';
            const title = trigger.getAttribute('data-confirm-title') || 'Confirmar Acción';
            const btnText = trigger.getAttribute('data-confirm-btn-text') || 'Confirmar';
            const btnClass = trigger.getAttribute('data-confirm-btn-class') || 'btn-danger';

            document.getElementById('globalConfirmModalBody').textContent = message;
            document.getElementById('globalConfirmModalLabel').textContent = title;

            const actionBtn = document.getElementById('globalConfirmActionBtn');
            actionBtn.textContent = btnText;
            actionBtn.className = `btn ${btnClass}`;

            // Guardar referencia
            // Si es un botón dentro de un form, guardamos el form. Si es un enlace, guardamos el enlace.
            if (trigger.type === 'submit' || trigger.closest('form')) {
                targetElement = trigger.closest('form');
            } else if (trigger.tagName === 'A') {
                targetElement = trigger;
            } else {
                // Caso genérico, quizás un botón que hace otra cosa via JS, pero por ahora soportamos forms y links
                targetElement = trigger;
            }

            if (confirmModal) {
                confirmModal.show();
            } else {
                // Fallback
                if (confirm(message)) {
                    executeAction();
                }
            }
        }
    });

    const actionBtn = document.getElementById('globalConfirmActionBtn');
    if (actionBtn) {
        actionBtn.addEventListener('click', function () {
            executeAction();
            if (confirmModal) confirmModal.hide();
        });
    }

    function executeAction() {
        if (!targetElement) return;

        if (targetElement.tagName === 'FORM') {
            targetElement.submit();
        } else if (targetElement.tagName === 'A' && targetElement.href) {
            window.location.href = targetElement.href;
        } else {
            // Disparar evento personalizado para manejo manual
            const event = new CustomEvent('confirmed', { bubbles: true });
            targetElement.dispatchEvent(event);
        }
    }
});
